# Importing Required Libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Load Dataset
df = pd.read_csv('sample_dataset.csv')
# print(df.head())

# Data Cleaning
# we can assume timestamp is not needed for predictions
df = df.drop('timestamp', axis=1)
# Drop rows with missing values
df = df.dropna()

# Encode categorical variables
le = preprocessing.LabelEncoder()
df['gender'] = le.fit_transform(df['gender'])

# print(df.head())

# Define Features and Target
features = df.drop('ratings', axis=1)
target = df['ratings']

# Split into training and test datasets
features_train, features_test, target_train, target_test = train_test_split(features, target, test_size=0.2)

# Define Classifiers
classifiers = [("Logistic Regression", LogisticRegression(solver='liblinear')),
               ("K-Nearest Neighbors", KNeighborsClassifier()),
               ("Decision Trees", DecisionTreeClassifier()), ("Random Forest", RandomForestClassifier()),
               ("Support Vector Machines", SVC()), ("Gradient Boosting", GradientBoostingClassifier())]

# Train classifiers and make predictions
for name, clf in classifiers:
    clf.fit(features_train, target_train)  # Training
    predictions = clf.predict(features_test)  # Predictions
    accuracy = accuracy_score(target_test, predictions)  # Accuracy
    print(name, "Accuracy: ", round(accuracy * 100, 2), "%")
